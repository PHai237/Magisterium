import { useState } from "react";

import { Button } from "../components/ui/Button";
import type { CharacterSnapshot } from "../domain/magisterium.types";
import { readStoredUserId, writeStoredUserId } from "../lib/storage/user-scope";
import { BattlePanel } from "../features/battles/BattlePanel";
import { CharacterPanel } from "../features/characters/CharacterPanel";

type ActiveView = "characters" | "battle";

export function App() {
  const [activeView, setActiveView] = useState<ActiveView>("characters");
  const [userId, setUserId] = useState(readStoredUserId);
  const [currentCharacter, setCurrentCharacter] = useState<CharacterSnapshot | null>(null);

  function updateUserId(nextUserId: string) {
    setUserId(nextUserId);
    writeStoredUserId(nextUserId);
    setCurrentCharacter(null);
  }

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <span className="brand__mark">M</span>
          <div>
            <h1>Magisterium</h1>
            <p>Phase 5 UI Foundation</p>
          </div>
        </div>

        <label className="user-scope">
          Dev user scope
          <input
            value={userId}
            onChange={(event) => updateUserId(event.target.value)}
            placeholder="user_1"
          />
        </label>

        <nav className="nav-stack">
          <Button
            variant={activeView === "characters" ? "primary" : "ghost"}
            onClick={() => setActiveView("characters")}
          >
            Character
          </Button>
          <Button
            variant={activeView === "battle" ? "primary" : "ghost"}
            onClick={() => setActiveView("battle")}
          >
            Battle
          </Button>
        </nav>

        <div className="sidebar-note">
          <strong>Current</strong>
          <span>{currentCharacter?.name ?? "No character selected"}</span>
        </div>
      </aside>

      <section className="workspace">
        <header className="workspace-header">
          <div>
            <p className="eyebrow">Clean rebuild</p>
            <h2>{activeView === "characters" ? "Character Console" : "Battle Console"}</h2>
          </div>
          <p>
            API-first shell. Replace visuals freely later without rewriting the backend contract.
          </p>
        </header>

        {activeView === "characters" ? (
          <CharacterPanel
            userId={userId}
            onCurrentCharacterChange={setCurrentCharacter}
          />
        ) : (
          <BattlePanel
            userId={userId}
            currentCharacter={currentCharacter}
            onCharacterUpdated={setCurrentCharacter}
          />
        )}
      </section>
    </main>
  );
}
