import { useCallback, useEffect, useMemo, useState } from "react";

import { Badge } from "../../components/ui/Badge";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { EmptyState } from "../../components/ui/EmptyState";
import { StatBar } from "../../components/ui/StatBar";
import { ORIGIN_OPTIONS, STAT_KEYS } from "../../domain/magisterium.constants";
import type {
  CharacterSnapshot,
  InventoryItemStack,
  ItemId,
  OriginId
} from "../../domain/magisterium.types";
import { compactLabel, formatNumber } from "../../lib/format";
import { charactersApi } from "./characters.api";

interface CharacterPanelProps {
  userId: string;
  onCurrentCharacterChange?: (character: CharacterSnapshot | null) => void;
}

interface LoadState {
  characters: CharacterSnapshot[];
  current: CharacterSnapshot | null;
  inventory: InventoryItemStack[];
}

const initialLoadState: LoadState = {
  characters: [],
  current: null,
  inventory: []
};

export function CharacterPanel({
  userId,
  onCurrentCharacterChange
}: CharacterPanelProps) {
  const [data, setData] = useState<LoadState>(initialLoadState);
  const [name, setName] = useState("Magica");
  const [originId, setOriginId] = useState<OriginId>("mercenary");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const loadCharacters = useCallback(async () => {
    setBusy(true);
    setError(null);

    try {
      const [characters, current] = await Promise.all([
        charactersApi.list(userId),
        charactersApi.getCurrent(userId)
      ]);

      const inventory = current
        ? await charactersApi.getInventory(userId, current.id)
        : [];

      setData({
        characters,
        current,
        inventory
      });

      onCurrentCharacterChange?.(current);
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : "Failed to load characters.");
    } finally {
      setBusy(false);
    }
  }, [onCurrentCharacterChange, userId]);

  useEffect(() => {
    void loadCharacters();
  }, [loadCharacters]);

  const equippedItemSet = useMemo(
    () => new Set(data.current?.equippedItemIds ?? []),
    [data.current?.equippedItemIds]
  );

  async function createCharacter() {
    setBusy(true);
    setError(null);

    try {
      const created = await charactersApi.create(userId, {
        name,
        originId
      });

      const inventory = await charactersApi.getInventory(userId, created.id);

      setData((previous) => ({
        characters: [...previous.characters, created],
        current: created,
        inventory
      }));

      onCurrentCharacterChange?.(created);
    } catch (createError) {
      setError(createError instanceof Error ? createError.message : "Failed to create character.");
    } finally {
      setBusy(false);
    }
  }

  async function selectCharacter(characterId: string) {
    setBusy(true);
    setError(null);

    try {
      const current = await charactersApi.setCurrent(userId, characterId);
      const inventory = await charactersApi.getInventory(userId, current.id);

      setData((previous) => ({
        ...previous,
        current,
        inventory
      }));

      onCurrentCharacterChange?.(current);
    } catch (selectError) {
      setError(selectError instanceof Error ? selectError.message : "Failed to set current character.");
    } finally {
      setBusy(false);
    }
  }

  async function mutateItem(action: "equip" | "unequip" | "use", itemId: ItemId) {
    if (!data.current) {
      return;
    }

    setBusy(true);
    setError(null);

    try {
      const result =
        action === "equip"
          ? await charactersApi.equip(userId, data.current.id, itemId)
          : action === "unequip"
            ? await charactersApi.unequip(userId, data.current.id, itemId)
            : await charactersApi.useConsumable(userId, data.current.id, itemId);

      const current = result.character;
      const inventory = await charactersApi.getInventory(userId, current.id);

      setData((previous) => ({
        ...previous,
        current,
        characters: previous.characters.map((character) =>
          character.id === current.id ? current : character
        ),
        inventory
      }));

      onCurrentCharacterChange?.(current);
    } catch (mutationError) {
      setError(mutationError instanceof Error ? mutationError.message : "Item action failed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="feature-grid">
      <Card eyebrow="Character" title="Create / Select">
        <div className="form-grid">
          <label>
            Name
            <input value={name} onChange={(event) => setName(event.target.value)} />
          </label>

          <label>
            Origin
            <select
              value={originId}
              onChange={(event) => setOriginId(event.target.value as OriginId)}
            >
              {ORIGIN_OPTIONS.map((origin) => (
                <option key={origin.id} value={origin.id}>
                  {origin.label}
                </option>
              ))}
            </select>
          </label>

          <Button disabled={busy} onClick={createCharacter}>
            Create character
          </Button>
        </div>

        <div className="option-list">
          {ORIGIN_OPTIONS.map((origin) => (
            <div key={origin.id} className="option-card">
              <strong>{origin.label}</strong>
              <span>{origin.description}</span>
            </div>
          ))}
        </div>
      </Card>

      <Card
        eyebrow="Roster"
        title="Characters"
        action={
          <Button variant="secondary" disabled={busy} onClick={loadCharacters}>
            Refresh
          </Button>
        }
      >
        {error && <p className="error-banner">{error}</p>}

        {data.characters.length === 0 ? (
          <EmptyState
            title="No character yet"
            description="Create a character to unlock the battle playground."
          />
        ) : (
          <div className="roster-list">
            {data.characters.map((character) => (
              <button
                key={character.id}
                className={`roster-card ${
                  data.current?.id === character.id ? "roster-card--active" : ""
                }`}
                onClick={() => void selectCharacter(character.id)}
              >
                <strong>{character.name}</strong>
                <span>
                  Lv. {character.progression.level} · {compactLabel(character.originId)}
                </span>
              </button>
            ))}
          </div>
        )}
      </Card>

      <Card eyebrow="Sheet" title={data.current?.name ?? "Current Character"}>
        {!data.current ? (
          <EmptyState
            title="No current character"
            description="Select or create a character first."
          />
        ) : (
          <div className="character-sheet">
            <div className="resource-grid">
              <StatBar
                label="HP"
                value={data.current.currentState.hp}
                max={data.current.derivedStats.maxHp}
              />
              <StatBar
                label="MP"
                value={data.current.currentState.mp}
                max={data.current.derivedStats.maxMp}
              />
              <StatBar
                label="Stamina"
                value={data.current.currentState.stamina}
                max={data.current.derivedStats.maxStamina}
              />
            </div>

            <div className="stat-grid">
              {STAT_KEYS.map((statKey) => (
                <div key={statKey} className="stat-chip">
                  <span>{statKey}</span>
                  <strong>{data.current?.baseStats[statKey]}</strong>
                </div>
              ))}
            </div>

            <div className="metric-grid">
              <div>
                <span>Level</span>
                <strong>{data.current.progression.level}</strong>
              </div>
              <div>
                <span>EXP</span>
                <strong>{formatNumber(data.current.progression.exp)}</strong>
              </div>
              <div>
                <span>Bronze</span>
                <strong>{formatNumber(data.current.moneyBronze)}</strong>
              </div>
              <div>
                <span>Fatigue</span>
                <strong>{formatNumber(data.current.fatigue, 2)}</strong>
              </div>
            </div>

            <div className="badge-row">
              {data.current.equippedSkillIds.map((skillId) => (
                <Badge key={skillId}>{compactLabel(skillId)}</Badge>
              ))}
            </div>
          </div>
        )}
      </Card>

      <Card eyebrow="Inventory" title="Stacks / Equipment / Consumables">
        {!data.current ? (
          <EmptyState
            title="Inventory locked"
            description="Select a current character to inspect inventory."
          />
        ) : data.inventory.length === 0 ? (
          <EmptyState title="Empty inventory" description="No items found." />
        ) : (
          <div className="inventory-list">
            {data.inventory.map((stack) => {
              const isEquipped = equippedItemSet.has(stack.itemId);

              return (
                <article key={stack.itemId} className="inventory-row">
                  <div>
                    <strong>{compactLabel(stack.itemId)}</strong>
                    <span>Quantity: {stack.quantity}</span>
                    {isEquipped && <Badge>Equipped</Badge>}
                  </div>

                  <div className="row-actions">
                    <Button
                      variant="secondary"
                      disabled={busy}
                      onClick={() => void mutateItem("equip", stack.itemId)}
                    >
                      Equip
                    </Button>
                    <Button
                      variant="ghost"
                      disabled={busy || !isEquipped}
                      onClick={() => void mutateItem("unequip", stack.itemId)}
                    >
                      Unequip
                    </Button>
                    <Button
                      variant="ghost"
                      disabled={busy}
                      onClick={() => void mutateItem("use", stack.itemId)}
                    >
                      Use
                    </Button>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </Card>
    </div>
  );
}
