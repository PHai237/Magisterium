import type { EncounterId, OriginId } from "./magisterium.types";

export const ORIGIN_OPTIONS: Array<{
  id: OriginId;
  label: string;
  description: string;
}> = [
  {
    id: "scholar",
    label: "Scholar",
    description: "INT/WIS caster start with early magical utility."
  },
  {
    id: "mercenary",
    label: "Mercenary",
    description: "STR/CON physical start with reliable weapon pressure."
  },
  {
    id: "wanderer",
    label: "Wanderer",
    description: "Balanced explorer profile with flexible survival tools."
  },
  {
    id: "street_urchin",
    label: "Street Urchin",
    description: "DEX/LUK agile start focused on speed and precision."
  },
  {
    id: "acolyte",
    label: "Acolyte",
    description: "WIS support start with healing-oriented growth."
  }
];

export const ENCOUNTER_OPTIONS: Array<{
  id: EncounterId;
  label: string;
  description: string;
}> = [
  {
    id: "slime_training",
    label: "Slime Training",
    description: "Safe first combat flow against a single slime."
  },
  {
    id: "goblin_scout",
    label: "Goblin Scout",
    description: "A sharper early encounter against a goblin."
  },
  {
    id: "forest_edge_mixed",
    label: "Forest Edge Mixed",
    description: "Small mixed encounter for testing multi-monster turns."
  }
];

export const STAT_KEYS = ["STR", "DEX", "CON", "INT", "WIS", "LUK"] as const;
